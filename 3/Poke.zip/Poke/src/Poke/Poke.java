package Poke;
import java.util.Scanner;

public class Poke {
	public static String[] createCard(int number) {
		
	}
	public static void display(String[] cards) {
		
	}
	public static void shuffle(String[] cards) {
		
	}
	public static void distribute(String[] cards, int player) {
		
	}
}
